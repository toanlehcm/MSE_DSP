%BAI 7.B
b=[2,-4,5/3,1.75];
a=[1,3/2,0,-3/4];
[R,p,C]=residuez(b,a)
r=abs(p(2))
[a,b] = residuez(R(1:2),p(1:2),-2.3333)