%BAI 7.A
b=[1,-2,3];
a=[1,2/3,-5/4];
[R,p,C]=residuez(b,a)
