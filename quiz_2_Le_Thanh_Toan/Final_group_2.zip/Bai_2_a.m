clc; close all;
n1 = -3:3;
x = [3 -2 4 -3 -1 4 5];
n2 = -1:3; 
h = [-1 1 -1 1 -1];
[y,n] = conv_m(x,n1,h,n2);
y, n