clc; close all;

w = [-300:300]*pi/300; 
a = [1 -1.15 1 0.0605 0.8045]; 
b = [1 -1 1];
[H] = freqresp(b,a,w);
magH = abs(H); 
phaH = angle(H)*180/pi;

subplot(2,1,1); 
plot(w/pi,magH); 
axis([-1 1 0 1.4]);
wtick = [-1:0.2:1]; 
magtick = [0:0.2:1.4];
xlabel('\omega / \pi'); 
ylabel('|H|');
title('Magnitude response');
set(gca,'XTick',wtick); 
set(gca,'YTick',magtick);
subplot(2,1,2); 
plot(w/pi,phaH,'LineWidth',1.5); 
axis([-1 1 -200 200]);
wtick = [-1:0.2:1]; 
magtick = [-180:60:180];
xlabel('\omega / \pi'); 
ylabel('Degrees');
title('Phase response');
set(gca,'XTick',wtick); 
set(gca,'YTick',magtick)