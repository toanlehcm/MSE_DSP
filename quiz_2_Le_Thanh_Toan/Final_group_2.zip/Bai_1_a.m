clc; close all;
n = [-10:5];
x = exp(0.2*(n+1)) .* (stepseq(-10,-10,5) - stepseq(5,-10,5));

stem (n,x);
title('Sequence of x(n)');
xlabel('x');
ylabel('x(n)');
