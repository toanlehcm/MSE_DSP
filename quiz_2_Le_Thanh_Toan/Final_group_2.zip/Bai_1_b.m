clc; close all;
n = [0:5];
x = 2*cos(0.2*pi*n) .* (stepseq(0,0,5) - stepseq(5,0,5));

x = x' * ones(1,4);
x = (x(:))';
n2 = [1:24]

stem (n2,x);
title('Sequence of x(n)');
xlabel('x');
ylabel('x(n)');
