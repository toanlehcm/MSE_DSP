clc; close all;
x0 = [2,3,-1,2,-4,5,-3];
n0 = [-3:3];

[xfold,nfold] = sigfold(x0,n0);

[x11,n11] = sigshift(x0,n0,-2);
[x12,n12] = sigshift(xfold,nfold,3);
[x1,n1] = sigmult(x11, n11, x12, n12);

[x21,n21] = sigshift(xfold,nfold,2);
[x22,n22] = sigshift(x0,n0,-2);
[x2,n2] = sigmult(x21, n21, x22, n22);

[x,n] = sigadd(x1,n1, x2,n2);

stem (n,x);
title('’Sequence x_1(n)');
xlabel('x');
ylabel('x(n)');
