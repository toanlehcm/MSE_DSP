clc; close all;
n = [0:10];
[x1,n1] = stepseq(1,0,10);
[x2,n2] = sigfold(x1,n1);


x = (3-n2) .* (0.7 .^ (n2 + 1)).*x2;
w = linspace(0,pi,201);

X = dtft(x,n2,w);
magX = abs(X); 
phaX = angle(X);

subplot(2,1,1); 
plot(w/pi,magX);
xlabel('\omega/\pi');
ylabel('|X|');
title('Magnitude response');

subplot(2,1,2); 
plot(w/pi,phaX*180/pi);
xlabel('\omega/\pi'); 
ylabel('Degrees');
title('Phase Response');
axis([-1,1,-180,180]); phatick = [-180 0 180];
set(gca,'XTick',wtick);
set(gca,'YTick',phatick);