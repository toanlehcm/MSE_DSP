function [y ny]=dnsample(x,n,M)
param=n/M;
samp=fix(param)==param;
y=x(samp==1);
ny=n(samp==1)/M;
end