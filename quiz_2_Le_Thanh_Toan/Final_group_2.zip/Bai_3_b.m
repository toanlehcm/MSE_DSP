clc; close all;
n = [0:10];
[x1,n1] = stepseq(0,0,10);


x = ((0.3 .^ (n1)) + (0.4 .^ (-n1)) ) .* x1;
w = linspace(-pi,pi,201);

X = dtft(x,n2,w);
magX = abs(X); 
phaX = angle(X);

subplot(2,1,1); 
plot(w/pi,magX);
xlabel('\omega/\pi');
ylabel('|X|');
title('Magnitude response');

subplot(2,1,2); 
plot(w/pi,phaX*180/pi);
xlabel('\omega/\pi'); 
ylabel('Degrees');
title('Phase Response');
axis([-1,1,-180,180]); phatick = [-180 0 180];
set(gca,'XTick',wtick);
set(gca,'YTick',phatick);
